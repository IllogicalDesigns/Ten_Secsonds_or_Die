﻿using UnityEngine;
using System.Collections;

public class FireBalls : MonoBehaviour 
{
	

public Rigidbody ball;
private int speed = 20;


void FireRocket () 
{
	Rigidbody ballClone = (Rigidbody) Instantiate(ball, transform.position, transform.rotation);
	ballClone.velocity = transform.forward * speed;
}


void Update () 
{
	if (Input.GetButtonDown("Fire1"))
	{
		FireRocket();
	}
}
	
}