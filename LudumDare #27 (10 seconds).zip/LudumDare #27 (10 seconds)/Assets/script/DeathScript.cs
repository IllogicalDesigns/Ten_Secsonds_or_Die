﻿using UnityEngine;
using System.Collections;

public class DeathScript : MonoBehaviour {
	public GameObject painTexture;
	public AudioClip Pain;
	public string levelToLoad;
	private int Count = 0;
	private bool dead = false;
	
	
	void FixedUpdate ()
	{
		if(dead)
		{
			Count ++;
		}
	}
	
	
	
	// Update is called once per frame
	void OnTriggerStay () 
	{
		dead = true;
		
		//enable painTexture
		
		
		if(Count == 120)
		{
			Application.LoadLevel (levelToLoad);
		}
	}
}
		
	


		
	

