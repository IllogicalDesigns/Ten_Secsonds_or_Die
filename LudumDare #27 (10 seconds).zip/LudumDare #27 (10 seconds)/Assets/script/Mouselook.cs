﻿using UnityEngine;
using System.Collections;

public class Mouselook : MonoBehaviour 
{
private float UpSpeed = 400;
	
	void FixedUpdate () 
	{
	// this will rotate the camera	
	float MRotate = Input.GetAxis("Mouse Y") * UpSpeed * Time.deltaTime; //input up and down
		
	transform.Rotate(Vector3.left * MRotate); //output up and down		
		
	}
}
