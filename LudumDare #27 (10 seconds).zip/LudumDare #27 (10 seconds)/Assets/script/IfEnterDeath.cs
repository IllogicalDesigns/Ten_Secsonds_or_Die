﻿using UnityEngine;
using System.Collections;

public class IfEnterDeath : MonoBehaviour {
	public GameObject platform;
	public static bool Dead = false;


	
	// Update is called once per frame
	void OnTriggerEnter (Collider other) 
	{
		if(other.tag == "Big")
		{
		platform.gameObject.collider.enabled = false;
		Application.LoadLevel ("Game Over");
		Debug.Log("Death");
		}
	}
}
