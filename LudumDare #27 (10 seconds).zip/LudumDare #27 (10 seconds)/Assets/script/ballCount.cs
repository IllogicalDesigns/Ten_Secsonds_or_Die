﻿using UnityEngine;
using System.Collections;

public class ballCount : MonoBehaviour {

	public static int balls = 0;
	public string levelToLoad;
	private int Count = 0;
	
	// Update is called once per frame
	void Update () 
	{
		
	guiText.text = ("You have this many balls " + balls + " out of 5");
		
	if(Count >= 120)
		{
			Application.LoadLevel (levelToLoad);
		}
	
	}
	
	void FixedUpdate()
	{
		if(balls >= 5)
		{
			Count++;
		}
	}
}
