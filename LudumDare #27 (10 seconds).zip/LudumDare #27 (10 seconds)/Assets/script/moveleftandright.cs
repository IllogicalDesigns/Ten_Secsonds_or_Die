﻿using UnityEngine;
using System.Collections;

public class moveleftandright : MonoBehaviour {
	private int MSpeed = 10;
	private int RSpeed = 10;
	
	
	void FixedUpdate () 
	{
		
	float MLeft = Input.GetAxis("Horizontal")  * MSpeed * Time.deltaTime; //input Horizontal
    float MRotate = Input.GetAxis("Mouse X") * RSpeed * Time.deltaTime; //input Horizontal


    // Move the player
	transform.Translate(Vector3.left * -MLeft);  				//output move left
    transform.Rotate(Vector3.up * MRotate * 10);
	
		
	}
}

