﻿using UnityEngine;
using System.Collections;

public class Balls : MonoBehaviour {
	public Rigidbody ball;
	private int speed = 1;
	private int Count = 0;


	
	// Update is called once per frame
	void FixedUpdate () 
	{
		Count ++;
		
		if(Count >= 60)
		{
			Rigidbody ballClone = (Rigidbody) Instantiate(ball, transform.position, transform.rotation);
			ballClone.velocity = transform.forward * speed;
			Count = 0;
		}
	}
}
