﻿using UnityEngine;
using System.Collections;

public class FireBalls2 : MonoBehaviour {

	public Rigidbody ball;
	private int speed = 20;
	private int Count = 30;


	
	// Update is called once per frame
	void FixedUpdate () 
	{
		if(Count <= 16)
		{
		Count ++;
		Debug.Log(Count);
		}
		
		if (Input.GetButtonDown("Fire1"))
		{
			if(Count >= 15)
			{
				Rigidbody ballClone = (Rigidbody) Instantiate(ball, transform.position, transform.rotation);
				ballClone.velocity = transform.forward * speed;
				Count = 0;
			}
		}
	}
}
