﻿using UnityEngine;
using System.Collections;

public class Press_space_to_start : MonoBehaviour {
	
	public string levelToLoad;

	// Update is called once per frame
	void Update () 
	{
		if(Input.GetKeyDown(KeyCode.Space))
		{
			Application.LoadLevel (levelToLoad);
		}
			
	}
}
