﻿using UnityEngine;
using System.Collections;

public class Ballcounter : MonoBehaviour {
	
	// Update is called once per frame
	void OnTriggerExit () 
	{
		//Compare tags
	ballCount.balls ++;
	}
}
