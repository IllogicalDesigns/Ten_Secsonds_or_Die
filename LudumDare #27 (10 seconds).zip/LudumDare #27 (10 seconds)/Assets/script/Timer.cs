﻿using UnityEngine;
using System.Collections;

public class Timer : MonoBehaviour {
	private int Count = 0;
	public GameObject platform;
	
	
	// Update is called once per frame
	void FixedUpdate () 
	{
		Count++;
		
		if(Count == 60 && ballCount.balls < 5)//1
		{
			guiText.text = ("timer:9");
			
		}
		
		if(Count == 120 && ballCount.balls < 5)//2
		{
			guiText.text = ("timer:8");
		}
		
		if(Count == 180 && ballCount.balls < 5)//3
		{
			guiText.text = ("timer:7");
		}
		
		if(Count == 240 && ballCount.balls < 5)//4
		{
			guiText.text = ("timer:6");
		}
		
		if(Count == 300 && ballCount.balls < 5)//5
		{
			guiText.text = ("timer:5");
		}
		
		if(Count == 360 && ballCount.balls < 5)//6
		{
			guiText.text = ("timer:4");
		}
		
		if(Count == 420 && ballCount.balls < 5)//7
		{
			guiText.text = ("timer:3");
		}
		
		if(Count == 480 && ballCount.balls < 5)//8
		{
			guiText.text = ("timer:2");
		}
		
		if(Count == 540 && ballCount.balls < 5)//9
		{
			guiText.text = ("timer:1 Also your about to die :d");
			audio.Play();
		}
		
		if(Count == 600 && ballCount.balls < 5)//10
		{
			guiText.text = ("timer: Bye Bye");
			
			
			platform.gameObject.collider.enabled = false;
			platform.gameObject.renderer.enabled = false;
			Debug.Log("dead");
		}
	
	}
}
