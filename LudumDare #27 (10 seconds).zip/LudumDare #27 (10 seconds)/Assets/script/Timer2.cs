﻿using UnityEngine;
using System.Collections;

public class Timer2 : MonoBehaviour {
	private int Count = 0;
	public GameObject platform;
	
	void Start ()
	{
		ballCount.balls = 0;
	}
	
	// Update is called once per frame
	void FixedUpdate () 
	{
		Count++;
		
		if(Count == 60)//1
		{
			guiText.text = ("timer:9");
			
		}
		
		if(Count == 120)//2
		{
			guiText.text = ("timer:8");
		}
		
		if(Count == 180)//3
		{
			guiText.text = ("timer:7");
		}
		
		if(Count == 240)//4
		{
			guiText.text = ("timer:6");
		}
		
		if(Count == 300)//5
		{
			guiText.text = ("timer:5");
		}
		
		if(Count == 360)//6
		{
			guiText.text = ("timer:4");
		}
		
		if(Count == 420)//7
		{
			guiText.text = ("timer:3");
		}
		
		if(Count == 480)//8
		{
			guiText.text = ("timer:2");
		}
		
		if(Count == 540)//9
		{
			guiText.text = ("timer:1");
			audio.Play();
		}
		
		if(Count == 600)//10
		{
			guiText.text = ("timer: Your done");
			
			
			platform.gameObject.collider.enabled = true;
			platform.gameObject.renderer.enabled = true;
		}
		
		if(Count == 720 && IfEnterDeath.Dead == false)
		{
			Application.LoadLevel ("Win");
		}
	
	}
}
